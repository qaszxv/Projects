/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

/**
 *
 * @author hungle
 */
public class PercolationStats {
    
    private int N, trials; 
    private double[] Monte; 
    
    public PercolationStats(int n, int trials)    // perform trials independent experiments on an n-by-n grid
    {
        if (n <= 0 || trials <= 0) 
            throw new IllegalArgumentException(Integer.toString(n));
        else {
            
            this.N = n; 
            this.trials = trials; 
            for (int i = 0; i < trials; i++) {
                
                runTest(i); 
                
            }
            this.Monte = new double[trials];    
        }
        
    }
    
    private void runTest(int i) {
        final Percolation perco = new Percolation(N); 
        int count = 0; 
        while (!perco.percolates()) {
            System.out.println("This" + count);
            int row = StdRandom.uniform(1, N); 
            int col = StdRandom.uniform(1, N); 
            if (!perco.isOpen(row, col)) {
                perco.open(row, col);
                count++; 
            }
        }
        double maxSize = N*N; 
        Monte[i] = count/maxSize; 
    }
    
    public double mean()                          // sample mean of percolation threshold
    {
        return StdStats.mean(Monte); 
    }
    public double stddev()                        // sample standard deviation of percolation threshold
    {
        return StdStats.stddev(Monte); 
    }
    public double confidenceLo()                  // low  endpoint of 95% confidence interval
    {
        return mean() - 1.96*stddev()/Math.sqrt(trials); 
    }
    public double confidenceHi()                  // high endpoint of 95% confidence interval
    {
        return mean() + 1.96*stddev()/Math.sqrt(trials); 
    }
    
    public static void main(String[] args)        // test client (described below)
    {
        /*if (args.length != 2) {
            System.out.println("Usage: PercolationStats N T");
            return;
        }

        final int N = Integer.valueOf(args[0]);
        final int T = Integer.valueOf(args[1]);*/
        
        final PercolationStats ps = new PercolationStats(3, 1);
        System.out.printf("mean                     = %f\n", ps.mean());
        System.out.printf("stddev                   = %f\n", ps.stddev());
        System.out.printf("95%% confidence interval  = %f, %f\n", ps.confidenceHi(), ps.confidenceLo());
    }

      
}
